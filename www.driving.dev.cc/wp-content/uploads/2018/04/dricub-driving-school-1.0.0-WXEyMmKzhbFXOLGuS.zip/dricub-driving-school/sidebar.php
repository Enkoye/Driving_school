<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package dricub_driving_school
 */

if (is_active_sidebar('blog_sideber')) {
	dynamic_sidebar('blog_sideber');
}